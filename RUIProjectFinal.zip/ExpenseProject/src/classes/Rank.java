package classes;

public enum Rank {
    
    BRONZE(0), SILVER(.025), ROSE(.035), GOLD(.05), ELITE(.075), PREMIUM(.10);
    
    double discount;
    
    Rank(double discount) {
        this.discount = discount;
    }
    
    public double getDiscount() {
        return discount;
    }
}
